## AutoAPI Gen — Upgraded

Full-stack web app that:
- Uploads an Express (Node.js) or FastAPI (Python) backend project as a ZIP
- Analyzes routes using AST parsing (Babel for JS/TS, Python's `ast` module for Python)
- Generates an OpenAPI 3.0.3 spec (optionally AI-enhanced via OpenAI)
- Renders Swagger UI documentation with dark mode support
- Provides an interactive "Try It" API explorer with request history
- Generates downloadable client SDK ZIPs (JavaScript, Python, Java) with READMEs

---

### Prerequisites

- **Node.js 18+** — [Download](https://nodejs.org/en/download)
- **Python 3.x** (optional, recommended) — for best FastAPI AST analysis. Falls back to regex if unavailable.
- **OpenAI API key** (optional) — for AI-enhanced OpenAPI descriptions

---

### Quick Start

#### 1. Backend

```bash
cd backend
npm install

# Optional: create .env from template
cp .env.example .env
# then edit .env to add your OPENAI_API_KEY

npm run dev       # uses nodemon for auto-reload
# or
npm start         # plain node
```

Backend runs on `http://localhost:5000`.

#### 2. Frontend

```bash
cd frontend
npm install

# Optional: set backend URL
cp .env.example .env.local

npm run dev
```

Frontend runs on `http://localhost:3000`.

---

### Usage

1. Open `http://localhost:3000`
2. Upload a backend ZIP (drag & drop or click to browse)
3. In **Dashboard**: click **Analyze code** — detects all routes
4. Click **Generate OpenAPI** — builds the OpenAPI 3.0.3 spec (AI-enhanced if `OPENAI_API_KEY` is set)
5. Navigate to:
   - **Documentation** — Swagger UI with download button
   - **API Explorer** — live request testing with request history
   - **SDK Downloads** — download JS / Python / Java SDK ZIPs

---

### Backend API

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Health check |
| POST | `/upload` | Upload project ZIP → `{ projectId }` |
| POST | `/analyze` | `{ projectId }` → `{ analysis }` |
| POST | `/generate-docs` | `{ projectId }` → `{ openapi }` |
| GET | `/docs?projectId=...` | Get OpenAPI JSON |
| POST | `/sdk` | `{ projectId, language }` → ZIP download |

---

### Upgrade Notes (v1.1.0)

**Frontend fixes:**
- Removed all illegal `require()` inside React components — now uses proper ES imports
- Active nav highlighting in sidebar
- Dark mode Swagger UI CSS fixes
- Drag-and-drop file upload with visual feedback
- Dashboard shows live success/error feedback + stat cards
- Explorer adds Headers field, request history, JSON validation feedback
- SDK page shows download confirmation and language descriptions
- Added `next.config.js` to fix webpack warnings

**Backend fixes:**
- Fixed Python analyzer path (`backend/python/` not `../../python`)
- Added `python3`/`python` fallback for cross-platform compatibility
- Added `dotenv` support — configure via `.env`
- Added `nodemon` for dev hot-reload
- OpenAPI service strips markdown code fences from AI response
- `extractService` uses `path.resolve` for path traversal security fix
- `extractService` cleans up uploaded ZIP after extraction
- `projectStore` auto-purges projects older than 2 hours
- OpenAPI spec now includes `operationId`, tags, and richer response schemas
- SDK files now include READMEs and JSDoc comments
- Java SDK fixes: proper URL building, UTF-8 path encoding
- Added `/health` endpoint
