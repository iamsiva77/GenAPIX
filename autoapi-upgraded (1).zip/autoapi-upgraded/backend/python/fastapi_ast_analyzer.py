import ast
import json
import os
import sys


HTTP_METHODS = {"get", "post", "put", "delete", "patch", "options", "head"}


def _get_str(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _decorator_info(dec):
    # Matches: @app.get("/x") or @router.post("/x")
    if not isinstance(dec, ast.Call):
        return None
    if not isinstance(dec.func, ast.Attribute):
        return None
    method = dec.func.attr.lower()
    if method not in HTTP_METHODS:
        return None
    path = None
    if dec.args:
        path = _get_str(dec.args[0])
    if not path:
        return None
    return method.upper(), path


def analyze_file(filename, root_dir):
    try:
        with open(filename, "r", encoding="utf-8") as f:
            code = f.read()
        tree = ast.parse(code, filename=filename)
    except Exception:
        return []

    endpoints = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for dec in node.decorator_list:
                info = _decorator_info(dec)
                if not info:
                    continue
                method, path = info
                endpoints.append(
                    {
                        "source": "fastapi",
                        "file": os.path.relpath(filename, root_dir).replace("\\", "/"),
                        "method": method,
                        "path": path,
                        "summary": (ast.get_docstring(node) or None),
                    }
                )
    return endpoints


def main():
    payload = json.loads(sys.stdin.read() or "{}")
    root_dir = payload.get("rootDir")
    files = payload.get("pyFiles") or []
    out = []
    for f in files:
        out.extend(analyze_file(f, root_dir))
    print(json.dumps({"framework": "fastapi", "endpoints": out}))


if __name__ == "__main__":
    main()

