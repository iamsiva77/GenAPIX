const express = require("express");
const router = express.Router();
const { generateDocs } = require("../controllers/docsController");

router.post("/", generateDocs);

module.exports = router;

