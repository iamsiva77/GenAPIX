const express = require("express");
const router = express.Router();
const { generateSDK } = require("../controllers/sdkController");

router.post("/", generateSDK);

module.exports = router;