require("dotenv").config();
const express = require("express");
const cors = require("cors");

const uploadRoutes = require("./routes/upload");
const analyzeRoutes = require("./routes/analyze");
const docsRoutes = require("./routes/docs");
const sdkRoutes = require("./routes/sdk");
const generateDocsRoutes = require("./routes/generateDocs");
const generateSdkRoutes = require("./routes/generateSdk");

const app = express();

app.use(cors({
  origin: process.env.FRONTEND_URL || "*",
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));
app.use(express.json({ limit: "5mb" }));

// Health check
app.get("/health", (req, res) => res.json({ status: "ok", ts: new Date().toISOString() }));

app.use("/upload", uploadRoutes);
app.use("/analyze", analyzeRoutes);
app.use("/generate-docs", generateDocsRoutes);
app.use("/docs", docsRoutes);
app.use("/sdk", sdkRoutes);
app.use("/generate-sdk", generateSdkRoutes);

// 404
app.use((req, res) => {
  res.status(404).json({ error: "NotFound", message: `Route ${req.method} ${req.path} not found` });
});

// Global error handler
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status || 500;
  console.error(`[${new Date().toISOString()}] ${status} ${req.method} ${req.path} —`, err.message);
  res.status(status).json({
    error: err.name || "Error",
    message: err.message || "Unexpected error",
    details: err.details
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ AutoAPI Gen backend running on http://localhost:${PORT}`));
