const { walkFiles } = require("../utils/fileWalk");
const { analyzeExpressFiles } = require("./analyzers/expressAnalyzer");
const { analyzeFastApiFiles } = require("./analyzers/fastapiAnalyzer");

async function analyzeProject(extractedDir) {
  const rootDir = extractedDir;

  const jsFiles = await walkFiles(rootDir, { exts: [".js", ".ts"] });
  const pyFiles = await walkFiles(rootDir, { exts: [".py"] });

  const results = [];
  if (jsFiles.length) {
    results.push(await analyzeExpressFiles(jsFiles, { rootDir }));
  }
  if (pyFiles.length) {
    results.push(await analyzeFastApiFiles(pyFiles, { rootDir }));
  }

  const endpoints = results.flatMap((r) => r.endpoints || []);
  const frameworks = [...new Set(results.map((r) => r.framework).filter(Boolean))];

  // Deduplicate endpoints by method+path
  const seen = new Set();
  const uniqueEndpoints = endpoints.filter((ep) => {
    const key = `${ep.method}:${ep.path}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  return {
    rootDir,
    frameworks,
    endpoints: uniqueEndpoints,
    stats: {
      jsFiles: jsFiles.length,
      pyFiles: pyFiles.length,
      endpoints: uniqueEndpoints.length,
      total: endpoints.length,
      duplicatesRemoved: endpoints.length - uniqueEndpoints.length
    }
  };
}

module.exports = { analyzeProject };
