const archiver = require("archiver");

function toIdentifier(s) {
  return (s || "")
    .replace(/[^A-Za-z0-9_]+/g, "_")
    .replace(/^_+/, "")
    .replace(/_+$/, "")
    .replace(/^(\d)/, "_$1")
    .toLowerCase();
}

function opId(method, p, existing) {
  if (existing) return toIdentifier(existing);
  return toIdentifier(`${method}_${p}`);
}

function listOperations(openapi) {
  const ops = [];
  const paths = openapi?.paths || {};
  for (const [p, item] of Object.entries(paths)) {
    for (const [method, op] of Object.entries(item || {})) {
      if (!op || typeof op !== "object") continue;
      ops.push({
        path: p,
        method: method.toUpperCase(),
        operationId: opId(method, p, op.operationId),
        summary: op.summary || `${method.toUpperCase()} ${p}`,
        parameters: op.parameters || [],
        requestBody: op.requestBody || null
      });
    }
  }
  return ops;
}

function renderJsSdk(openapi) {
  const ops = listOperations(openapi);
  const baseUrl = (openapi?.servers?.[0]?.url || "http://localhost:5000").replace(/"/g, '\\"');

  const fnDefs = ops.map((o) => {
    const pathParams = o.parameters.filter((p) => p.in === "path").map((p) => p.name);
    const queryParams = o.parameters.filter((p) => p.in === "query").map((p) => p.name);
    const hasBody = !!o.requestBody && !["GET", "HEAD"].includes(o.method);

    const jsdoc = [
      `/**`,
      ` * ${o.summary}`,
      ` * @param {AutoApiClient} client`,
      pathParams.length ? ` * @param {{ ${pathParams.map((p) => `${p}: string`).join(", ")} }} pathParams` : null,
      queryParams.length ? ` * @param {{ ${queryParams.map((p) => `${p}?: string`).join(", ")} }} query` : null,
      hasBody ? ` * @param {object} body` : null,
      ` * @returns {Promise<any>}`,
      ` */`
    ].filter(Boolean).join("\n");

    return `${jsdoc}
export async function ${toIdentifier(o.operationId)}(client, { pathParams = {}, query = {}, body, headers } = {}) {
  let p = "${o.path.replace(/"/g, '\\"')}";
  Object.entries(pathParams).forEach(([k, v]) => {
    p = p.replace(":" + k, encodeURIComponent(String(v)));
    p = p.replace("{" + k + "}", encodeURIComponent(String(v)));
  });
  return client.request({ method: "${o.method}", path: p, query, body, headers });
}`;
  });

  return `/**
 * AutoAPI Gen — JavaScript SDK
 * Generated automatically. Do not edit manually.
 */
import axios from "axios";

export class AutoApiClient {
  /**
   * @param {{ baseUrl?: string, defaultHeaders?: Record<string, string> }} opts
   */
  constructor({ baseUrl, defaultHeaders } = {}) {
    this.baseUrl = baseUrl || "${baseUrl}";
    this.defaultHeaders = defaultHeaders || {};
  }

  async request({ method, path, query, body, headers }) {
    const url = new URL(path, this.baseUrl);
    if (query) {
      Object.entries(query).forEach(([k, v]) => {
        if (v !== undefined && v !== null) url.searchParams.set(k, String(v));
      });
    }
    const res = await axios.request({
      method,
      url: url.toString(),
      data: body,
      headers: { ...this.defaultHeaders, ...(headers || {}) }
    });
    return res.data;
  }
}

export function createClient(opts) {
  return new AutoApiClient(opts);
}

${fnDefs.join("\n\n")}
`;
}

function renderPythonSdk(openapi) {
  const ops = listOperations(openapi);
  const baseUrl = (openapi?.servers?.[0]?.url || "http://localhost:5000").replace(/"/g, '\\"');

  const fnDefs = ops.map((o) => {
    const pathParams = o.parameters.filter((p) => p.in === "path").map((p) => p.name);
    const queryParams = o.parameters.filter((p) => p.in === "query").map((p) => p.name);
    const hasBody = !!o.requestBody && !["GET", "HEAD"].includes(o.method);
    const args = ["client"];
    if (pathParams.length) args.push("path_params=None");
    if (queryParams.length) args.push("query=None");
    if (hasBody) args.push("body=None");
    args.push("headers=None");

    return `def ${toIdentifier(o.operationId)}(${args.join(", ")}):
    """${o.summary}"""
    p = "${o.path.replace(/"/g, '\\"')}"
    if path_params:
        import urllib.parse
        for k, v in path_params.items():
            p = p.replace(":" + str(k), urllib.parse.quote(str(v), safe=""))
            p = p.replace("{" + str(k) + "}", urllib.parse.quote(str(v), safe=""))
    return client.request("${o.method}", p, query=${queryParams.length ? "query" : "None"}, body=${hasBody ? "body" : "None"}, headers=headers)`;
  });

  return `"""
AutoAPI Gen — Python SDK
Generated automatically. Do not edit manually.
"""
import requests
import urllib.parse


class AutoApiClient:
    def __init__(self, base_url="${baseUrl}", default_headers=None):
        self.base_url = base_url.rstrip("/")
        self.default_headers = default_headers or {}

    def request(self, method, path, query=None, body=None, headers=None):
        url = self.base_url + path
        h = dict(self.default_headers)
        if headers:
            h.update(headers)
        resp = requests.request(
            method=method,
            url=url,
            params=query or None,
            json=body,
            headers=h
        )
        resp.raise_for_status()
        try:
            return resp.json()
        except Exception:
            return resp.text


def create_client(**kwargs):
    """Create and return an AutoApiClient instance."""
    return AutoApiClient(**kwargs)


${fnDefs.join("\n\n")}
`;
}

function renderJavaSdk(openapi) {
  const ops = listOperations(openapi);
  const base = (openapi?.servers?.[0]?.url || "http://localhost:5000").replace(/"/g, '\\"');

  const methods = ops.map((o) => {
    const fn = toIdentifier(o.operationId);
    const pathParams = o.parameters.filter((p) => p.in === "path");
    const hasBody = !!o.requestBody && !["GET", "HEAD"].includes(o.method);

    const paramList = [
      ...pathParams.map((p) => `String ${toIdentifier(p.name)}`),
      hasBody ? "String jsonBody" : null,
      "Map<String, String> queryParams",
      "Map<String, String> headers"
    ].filter(Boolean).join(", ");

    let pathExpr = `"${o.path.replace(/"/g, '\\"')}"`;
    if (pathParams.length) {
      const replacements = pathParams.map((p) => {
        const id = toIdentifier(p.name);
        return `        path = path.replace("{${p.name}}", java.net.URLEncoder.encode(${id}, "UTF-8"));\n        path = path.replace(":${p.name}", java.net.URLEncoder.encode(${id}, "UTF-8"));`;
      }).join("\n");
      pathExpr = `calculatePath_${fn}(${pathParams.map((p) => toIdentifier(p.name)).join(", ")})`;

      return `    /** ${o.summary} */
    public String ${fn}(${paramList}) throws IOException {
        String path = calculatePath_${fn}(${pathParams.map((p) => toIdentifier(p.name)).join(", ")});
        return request("${o.method}", path, ${hasBody ? "jsonBody" : "null"}, queryParams, headers);
    }

    private String calculatePath_${fn}(${pathParams.map((p) => `String ${toIdentifier(p.name)}`).join(", ")}) {
        String path = "${o.path.replace(/"/g, '\\"')}";
        try {
${pathParams.map((p) => {
  const id = toIdentifier(p.name);
  return `            path = path.replace("{${p.name}}", java.net.URLEncoder.encode(${id}, "UTF-8"));\n            path = path.replace(":${p.name}", java.net.URLEncoder.encode(${id}, "UTF-8"));`;
}).join("\n")}
        } catch (java.io.UnsupportedEncodingException e) { /* utf-8 always supported */ }
        return path;
    }`;
    }

    return `    /** ${o.summary} */
    public String ${fn}(${paramList}) throws IOException {
        return request("${o.method}", ${pathExpr}, ${hasBody ? "jsonBody" : "null"}, queryParams, headers);
    }`;
  });

  return `package com.autoapigen;

import java.io.IOException;
import java.util.Map;
import okhttp3.*;

/**
 * AutoAPI Gen — Java SDK
 * Generated automatically. Do not edit manually.
 * Requires: com.squareup.okhttp3:okhttp:4.x
 */
public class AutoApiClient {
    private final OkHttpClient http = new OkHttpClient();
    private final String baseUrl;
    private final Headers defaultHeaders;
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    public AutoApiClient(String baseUrl, Map<String, String> defaultHeaders) {
        this.baseUrl = (baseUrl == null || baseUrl.isEmpty()) ? "${base}" : baseUrl;
        Headers.Builder b = new Headers.Builder();
        if (defaultHeaders != null) {
            for (Map.Entry<String, String> e : defaultHeaders.entrySet()) b.add(e.getKey(), e.getValue());
        }
        this.defaultHeaders = b.build();
    }

    public AutoApiClient() {
        this("${base}", null);
    }

    public String request(String method, String path, String jsonBody,
                          Map<String, String> queryParams, Map<String, String> headers) throws IOException {
        HttpUrl.Builder urlBuilder = HttpUrl.parse(baseUrl).newBuilder();
        // Append path segments safely
        for (String seg : path.replaceFirst("^/+", "").split("/", -1)) {
            urlBuilder.addPathSegment(seg);
        }
        if (queryParams != null) {
            for (Map.Entry<String, String> e : queryParams.entrySet()) {
                urlBuilder.addQueryParameter(e.getKey(), e.getValue());
            }
        }
        RequestBody body = null;
        if (jsonBody != null) body = RequestBody.create(jsonBody, JSON);

        Headers.Builder hb = defaultHeaders.newBuilder();
        if (headers != null) for (Map.Entry<String, String> e : headers.entrySet()) hb.add(e.getKey(), e.getValue());

        Request req = new Request.Builder()
            .url(urlBuilder.build())
            .method(method, body)
            .headers(hb.build())
            .build();

        try (Response res = http.newCall(req).execute()) {
            if (!res.isSuccessful()) throw new IOException("HTTP " + res.code() + ": " + (res.body() != null ? res.body().string() : ""));
            return res.body() != null ? res.body().string() : "";
        }
    }

    // ----- Operations -----

${methods.join("\n\n")}
}
`;
}

function sdkFilesForLanguage(language, openapi) {
  const lang = String(language || "").toLowerCase();
  if (lang === "javascript" || lang === "js") {
    return [
      {
        path: "javascript/package.json",
        content: JSON.stringify({
          name: "autoapi-sdk",
          version: "1.0.0",
          type: "module",
          description: "Auto-generated API client",
          main: "index.js",
          dependencies: { axios: "^1.6.0" }
        }, null, 2) + "\n"
      },
      { path: "javascript/index.js", content: renderJsSdk(openapi) },
      { path: "javascript/README.md", content: `# AutoAPI SDK — JavaScript\n\nInstall: \`npm install\`\n\nUsage:\n\`\`\`js\nimport { createClient } from "./index.js";\nconst client = createClient({ baseUrl: "http://localhost:5000" });\n\`\`\`\n` }
    ];
  }
  if (lang === "python" || lang === "py") {
    return [
      { path: "python/autoapi.py", content: renderPythonSdk(openapi) },
      { path: "python/README.md", content: `# AutoAPI SDK — Python\n\nInstall: \`pip install requests\`\n\nUsage:\n\`\`\`python\nfrom autoapi import create_client\nclient = create_client(base_url="http://localhost:5000")\n\`\`\`\n` }
    ];
  }
  if (lang === "java") {
    return [
      { path: "java/AutoApiClient.java", content: renderJavaSdk(openapi) },
      { path: "java/README.md", content: `# AutoAPI SDK — Java\n\nRequires: \`com.squareup.okhttp3:okhttp:4.x\`\n\nUsage:\n\`\`\`java\nAutoApiClient client = new AutoApiClient("http://localhost:5000", null);\n\`\`\`\n` }
    ];
  }
  return null;
}

function streamSdkZip({ res, language, openapi }) {
  const files = sdkFilesForLanguage(language, openapi);
  if (!files) return false;

  const lang = String(language).toLowerCase();
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Disposition", `attachment; filename="autoapi-sdk-${lang}.zip"`);

  const archive = archiver("zip", { zlib: { level: 9 } });
  archive.on("error", (err) => { throw err; });
  archive.pipe(res);
  for (const f of files) {
    archive.append(f.content, { name: f.path });
  }
  archive.finalize();
  return true;
}

module.exports = { streamSdkZip };
