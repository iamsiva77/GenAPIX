const crypto = require("crypto");

/**
 * In-memory project store.
 * For production, replace with a database or Redis.
 */
const projects = new Map();

// Auto-clean projects older than 2 hours to avoid memory leaks in long-running processes
const MAX_AGE_MS = 2 * 60 * 60 * 1000;
setInterval(() => {
  const now = Date.now();
  for (const [id, project] of projects) {
    if (now - new Date(project.createdAt).getTime() > MAX_AGE_MS) {
      projects.delete(id);
    }
  }
}, 30 * 60 * 1000); // Check every 30 min

function createProject({ originalName, uploadPath }) {
  const projectId = crypto.randomUUID();
  const now = new Date().toISOString();
  projects.set(projectId, {
    projectId,
    originalName,
    uploadPath,
    extractedDir: null,
    analyzedAt: null,
    analysis: null,
    openapi: null,
    createdAt: now,
    updatedAt: now
  });
  return projects.get(projectId);
}

function getProject(projectId) {
  return projects.get(projectId) || null;
}

function updateProject(projectId, patch) {
  const p = projects.get(projectId);
  if (!p) return null;
  const next = { ...p, ...patch, updatedAt: new Date().toISOString() };
  projects.set(projectId, next);
  return next;
}

function listProjects() {
  return [...projects.values()].map((p) => ({
    projectId: p.projectId,
    originalName: p.originalName,
    createdAt: p.createdAt,
    hasAnalysis: !!p.analysis,
    hasDocs: !!p.openapi
  }));
}

module.exports = { createProject, getProject, updateProject, listProjects };
