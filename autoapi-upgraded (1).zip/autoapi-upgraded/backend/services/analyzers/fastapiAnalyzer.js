const path = require("path");
const { spawn } = require("child_process");

// Try python3 first, fall back to python
function findPython() {
  return process.platform === "win32" ? ["python"] : ["python3", "python"];
}

function runPythonAnalyzer({ rootDir, pyFiles }) {
  const candidates = findPython();

  return new Promise((resolve, reject) => {
    // scriptPath: backend/python/fastapi_ast_analyzer.py
    const scriptPath = path.join(__dirname, "..", "..", "python", "fastapi_ast_analyzer.py");

    let tried = 0;
    function tryNext() {
      if (tried >= candidates.length) return reject(new Error("python / python3 not found on PATH"));
      const cmd = candidates[tried++];
      const py = spawn(cmd, [scriptPath], { stdio: ["pipe", "pipe", "pipe"] });

      let stdout = "";
      let stderr = "";
      py.stdout.on("data", (d) => (stdout += d.toString()));
      py.stderr.on("data", (d) => (stderr += d.toString()));
      py.on("error", tryNext); // command not found → try next candidate
      py.on("close", (code) => {
        if (code !== 0) return reject(new Error(stderr || `python exited ${code}`));
        try {
          resolve(JSON.parse(stdout));
        } catch (e) {
          reject(new Error(`Failed to parse python output: ${e.message}`));
        }
      });

      py.stdin.write(JSON.stringify({ rootDir, pyFiles }));
      py.stdin.end();
    }
    tryNext();
  });
}

async function analyzeFastApiFiles(pyFiles, { rootDir }) {
  try {
    return await runPythonAnalyzer({ rootDir, pyFiles });
  } catch {
    // Regex fallback when Python is unavailable
    const endpoints = [];
    const fs = require("fs/promises");
    const rel = (f) => require("path").relative(rootDir, f).replace(/\\/g, "/");
    const re = /@\w+\.(get|post|put|delete|patch|options|head)\(\s*["']([^"']+)["']/gi;
    for (const file of pyFiles) {
      const code = await fs.readFile(file, "utf8").catch(() => null);
      if (!code) continue;
      let m;
      while ((m = re.exec(code))) {
        endpoints.push({
          source: "fastapi",
          file: rel(file),
          method: m[1].toUpperCase(),
          path: m[2],
          summary: null,
          params: { path: [], query: [], header: [], body: null },
          responses: { "200": { description: "Success", content: { "application/json": { schema: {} } } } }
        });
      }
    }
    return { framework: "fastapi", endpoints };
  }
}

module.exports = { analyzeFastApiFiles };
