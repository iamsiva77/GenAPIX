const fs = require("fs/promises");
const path = require("path");
const parser = require("@babel/parser");
const traverse = require("@babel/traverse").default;

const HTTP_METHODS = new Set(["get", "post", "put", "delete", "patch", "options", "head"]);

function tryParse(code, filename) {
  return parser.parse(code, {
    sourceType: "unambiguous",
    plugins: [
      "jsx",
      "typescript",
      "classProperties",
      "decorators-legacy",
      "dynamicImport",
      "topLevelAwait"
    ],
    sourceFilename: filename
  });
}

function getStringLiteral(node) {
  if (!node) return null;
  if (node.type === "StringLiteral") return node.value;
  if (node.type === "TemplateLiteral" && node.expressions.length === 0) {
    return node.quasis[0]?.value?.cooked ?? null;
  }
  return null;
}

function normalizePath(p) {
  if (!p) return p;
  if (!p.startsWith("/")) return `/${p}`;
  return p;
}

function extractParamsFromPath(p) {
  const params = [];
  const re = /:([A-Za-z0-9_]+)/g;
  let m;
  while ((m = re.exec(p))) params.push(m[1]);
  return params;
}

async function analyzeExpressFiles(jsFiles, { rootDir }) {
  const endpoints = [];

  for (const file of jsFiles) {
    const code = await fs.readFile(file, "utf8");
    let ast;
    try {
      ast = tryParse(code, file);
    } catch {
      continue;
    }

    // Heuristic: routes usually are `app.get('/x', ...)` or `router.post('/x', ...)`
    traverse(ast, {
      CallExpression(p) {
        const callee = p.node.callee;
        if (!callee || callee.type !== "MemberExpression") return;
        if (callee.property?.type !== "Identifier") return;
        const method = callee.property.name?.toLowerCase();
        if (!HTTP_METHODS.has(method)) return;

        const args = p.node.arguments || [];
        const pathArg = args[0];
        const routePath = normalizePath(getStringLiteral(pathArg));
        if (!routePath) return;

        const pathParams = extractParamsFromPath(routePath);
        endpoints.push({
          source: "express",
          file: path.relative(rootDir, file).replace(/\\/g, "/"),
          method: method.toUpperCase(),
          path: routePath,
          summary: null,
          params: {
            path: pathParams.map((name) => ({ name, required: true, schema: { type: "string" } })),
            query: [],
            header: [],
            body: null
          },
          responses: {
            "200": { description: "Success", content: { "application/json": { schema: {} } } }
          }
        });
      }
    });
  }

  return { framework: "express", endpoints };
}

module.exports = { analyzeExpressFiles };

