const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const unzipper = require("unzipper");
const { HttpError } = require("../utils/httpError");

function isZip(filename) {
  return typeof filename === "string" && filename.toLowerCase().endsWith(".zip");
}

async function ensureDir(dir) {
  await fsp.mkdir(dir, { recursive: true });
}

function isPathInside(parent, child) {
  const rel = path.relative(parent, child);
  return !!rel && !rel.startsWith("..") && !path.isAbsolute(rel);
}

async function extractZipToDir(zipPath, destDir) {
  await ensureDir(destDir);
  const directory = await unzipper.Open.file(zipPath);

  for (const entry of directory.files) {
    // Normalize separators and reject path traversal
    const entryPath = entry.path.replace(/\\/g, "/");
    if (entryPath.includes("..") || entryPath.startsWith("/")) continue;

    const targetPath = path.resolve(destDir, entryPath);
    if (!isPathInside(destDir, targetPath)) continue;

    if (entry.type === "Directory") {
      await ensureDir(targetPath);
      continue;
    }

    await ensureDir(path.dirname(targetPath));
    await new Promise((resolve, reject) => {
      entry
        .stream()
        .pipe(fs.createWriteStream(targetPath))
        .on("finish", resolve)
        .on("error", reject);
    });
  }
}

async function extractUpload({ uploadPath, originalName, projectId }) {
  if (!isZip(originalName)) {
    throw new HttpError(
      400,
      "Only .zip uploads are supported.",
      "Please upload a ZIP of your backend project (Express or FastAPI)."
    );
  }
  const destDir = path.join(__dirname, "..", "projects", projectId);
  await extractZipToDir(uploadPath, destDir);

  // Clean up uploaded file after extraction
  await fsp.unlink(uploadPath).catch(() => {});

  return destDir;
}

module.exports = { extractUpload };
