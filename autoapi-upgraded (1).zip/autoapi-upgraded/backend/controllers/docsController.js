const { getProject, updateProject } = require("../services/projectStore");
const { HttpError } = require("../utils/httpError");
const { generateOpenApi } = require("../services/openapiService");

exports.generateDocs = async (req, res, next) => {
  try {
    const { projectId, title, version } = req.body || {};
    if (!projectId) throw new HttpError(400, "Missing projectId");

    const project = getProject(projectId);
    if (!project) throw new HttpError(404, "Unknown projectId — it may have expired. Re-upload your project.");
    if (!project.analysis) throw new HttpError(400, "Run /analyze first before generating docs.");

    const openapi = await generateOpenApi({
      analysis: project.analysis,
      title: title || project.originalName?.replace(/\.zip$/i, "") || "AutoAPI Gen",
      version: version || "1.0.0",
      apiKey: process.env.OPENAI_API_KEY
    });

    updateProject(projectId, { openapi });
    res.json({ projectId, openapi });
  } catch (e) {
    next(e);
  }
};

exports.getDocs = (req, res, next) => {
  try {
    const projectId = req.query.projectId;
    if (!projectId) throw new HttpError(400, "Missing projectId query parameter");

    const project = getProject(projectId);
    if (!project) throw new HttpError(404, "Unknown projectId — it may have expired.");
    if (!project.openapi) throw new HttpError(400, "No docs generated yet. Call POST /generate-docs first.");

    res.json(project.openapi);
  } catch (e) {
    next(e);
  }
};
