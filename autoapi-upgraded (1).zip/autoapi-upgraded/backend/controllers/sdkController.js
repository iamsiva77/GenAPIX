const { getProject } = require("../services/projectStore");
const { HttpError } = require("../utils/httpError");
const { streamSdkZip } = require("../services/sdkService");

exports.generateSDK = async (req, res, next) => {
  try {
    const { projectId, language } = req.body || {};
    if (!projectId) throw new HttpError(400, "Missing projectId");
    if (!language) throw new HttpError(400, "Missing language");

    const project = getProject(projectId);
    if (!project) throw new HttpError(404, "Unknown projectId");
    if (!project.openapi) throw new HttpError(400, "Generate docs first (POST /generate-docs).");

    const ok = streamSdkZip({ res, language, openapi: project.openapi });
    if (!ok) throw new HttpError(400, `Unsupported language: ${language}`);
  } catch (e) {
    next(e);
  }
};