const { getProject, updateProject } = require("../services/projectStore");
const { HttpError } = require("../utils/httpError");
const { analyzeProject } = require("../services/analyzeService");

exports.analyzeCode = async (req, res, next) => {
  try {
    const { projectId } = req.body || {};
    if (!projectId) throw new HttpError(400, "Missing projectId");

    const project = getProject(projectId);
    if (!project) throw new HttpError(404, "Unknown projectId");
    if (!project.extractedDir) throw new HttpError(400, "Project not extracted yet");

    const analysis = await analyzeProject(project.extractedDir);
    updateProject(projectId, { analysis, analyzedAt: new Date().toISOString() });

    res.json({ projectId, analysis });
  } catch (e) {
    next(e);
  }
};