const fs = require("fs/promises");
const path = require("path");
const multer = require("multer");
const { createProject, updateProject } = require("../services/projectStore");
const { extractUpload } = require("../services/extractService");

async function ensureUploadsDir() {
  const dir = path.join(__dirname, "..", "uploads");
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    try {
      const dir = await ensureUploadsDir();
      cb(null, dir);
    } catch (e) {
      cb(e);
    }
  },
  filename: (req, file, cb) => {
    const safe = String(file.originalname || "upload.zip").replace(/[^A-Za-z0-9._-]+/g, "_");
    cb(null, `${Date.now()}_${safe}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB
});

exports.uploadFile = [
  upload.single("file"),
  async (req, res, next) => {
    try {
      if (!req.file) return res.status(400).json({ message: "Missing file" });
      const project = createProject({ originalName: req.file.originalname, uploadPath: req.file.path });
      const extractedDir = await extractUpload({
        uploadPath: project.uploadPath,
        originalName: project.originalName,
        projectId: project.projectId
      });
      updateProject(project.projectId, { extractedDir });
      res.json({
        message: "Uploaded and extracted",
        projectId: project.projectId,
        extractedDir
      });
    } catch (e) {
      next(e);
    }
  }
];