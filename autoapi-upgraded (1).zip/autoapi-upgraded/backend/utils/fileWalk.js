const fsp = require("fs/promises");
const path = require("path");

const DEFAULT_IGNORES = new Set([
  "node_modules",
  ".git",
  ".next",
  "dist",
  "build",
  "__pycache__",
  ".venv",
  "venv"
]);

async function walkFiles(rootDir, { exts, ignores = DEFAULT_IGNORES } = {}) {
  const out = [];
  async function walk(dir) {
    const entries = await fsp.readdir(dir, { withFileTypes: true });
    for (const ent of entries) {
      if (ignores && ignores.has(ent.name)) continue;
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        await walk(full);
        continue;
      }
      if (exts && exts.length) {
        const lower = ent.name.toLowerCase();
        if (!exts.some((e) => lower.endsWith(e))) continue;
      }
      out.push(full);
    }
  }
  await walk(rootDir);
  return out;
}

module.exports = { walkFiles };

