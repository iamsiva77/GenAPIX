import Link from "next/link";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { getTheme, initTheme, setTheme } from "../lib/projectState";

const nav = [
  { href: "/dashboard", label: "Dashboard", icon: "🏠" },
  { href: "/docs", label: "Documentation", icon: "📖" },
  { href: "/explorer", label: "API Explorer", icon: "🧪" },
  { href: "/sdk", label: "SDK Downloads", icon: "⬇️" },
];

export function Layout({ title, children }) {
  const router = useRouter();
  const [theme, setThemeState] = useState("dark");

  useEffect(() => {
    initTheme();
    setThemeState(getTheme());
  }, []);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    setThemeState(next);
  };

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-zinc-950">
      {/* Top bar */}
      <div className="border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 sticky top-0 z-10">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <Link href="/" className="font-semibold tracking-tight dark:text-white flex items-center gap-2">
            <span>⚡</span> AutoAPI Gen
          </Link>
          <div className="flex items-center gap-3">
            <span className="hidden text-sm text-zinc-500 dark:text-zinc-400 sm:block">{title}</span>
            <button
              onClick={toggleTheme}
              className="rounded-md border border-zinc-200 dark:border-zinc-700 px-3 py-1.5 text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800 dark:text-zinc-300 transition-colors"
            >
              {theme === "dark" ? "☀️ Light" : "🌙 Dark"}
            </button>
          </div>
        </div>
      </div>

      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-4 px-4 py-5 md:grid-cols-[220px_1fr]">
        {/* Sidebar */}
        <aside className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 p-3 h-fit md:sticky md:top-16">
          <div className="mb-2 px-2 text-xs font-medium uppercase tracking-wider text-zinc-400">
            Navigation
          </div>
          <nav className="flex flex-col gap-0.5">
            {nav.map((n) => {
              const isActive = router.pathname === n.href;
              return (
                <Link
                  key={n.href}
                  href={n.href}
                  className={`rounded-lg px-3 py-2 text-sm flex items-center gap-2 transition-colors ${
                    isActive
                      ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 font-medium"
                      : "text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                  }`}
                >
                  <span>{n.icon}</span>
                  {n.label}
                </Link>
              );
            })}
          </nav>

          <div className="mt-4 px-2">
            <Link
              href="/"
              className="block rounded-lg border border-dashed border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs text-zinc-400 dark:text-zinc-500 hover:border-zinc-400 dark:hover:border-zinc-600 text-center transition-colors"
            >
              + Upload new project
            </Link>
          </div>
        </aside>

        {/* Main content */}
        <main className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 p-5 min-h-[500px]">
          {children}
        </main>
      </div>
    </div>
  );
}
