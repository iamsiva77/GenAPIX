import { useEffect, useMemo, useState } from "react";
import { Layout } from "../components/Layout";
import { api, BACKEND_URL } from "../lib/api";
import { getProjectId } from "../lib/projectState";

const METHOD_COLORS = {
  GET: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  POST: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
  PUT: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300",
  PATCH: "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300",
  DELETE: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
};

function listOps(spec) {
  const ops = [];
  const paths = spec?.paths || {};
  for (const [p, item] of Object.entries(paths)) {
    for (const [m, op] of Object.entries(item || {})) {
      ops.push({
        key: `${m.toUpperCase()} ${p}`,
        method: m.toUpperCase(),
        path: p,
        summary: op?.summary || "",
        parameters: op?.parameters || [],
        requestBody: op?.requestBody || null,
        responses: op?.responses || {}
      });
    }
  }
  return ops.sort((a, b) => a.path.localeCompare(b.path) || a.method.localeCompare(b.method));
}

function JsonTextarea({ label, value, onChange }) {
  const [err, setErr] = useState(null);
  const validate = (v) => {
    try { JSON.parse(v); setErr(null); } catch { setErr("Invalid JSON"); }
    onChange(v);
  };
  return (
    <label className="text-sm block">
      <div className="text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-1">{label}</div>
      <textarea
        value={value}
        onChange={(e) => validate(e.target.value)}
        className={`h-28 w-full rounded-lg border px-3 py-2 font-mono text-xs dark:bg-zinc-900 ${err ? "border-red-400" : "border-zinc-200 dark:border-zinc-700"}`}
      />
      {err && <div className="text-xs text-red-500 mt-1">{err}</div>}
    </label>
  );
}

export default function Explorer() {
  const [projectId, setProjectIdState] = useState(null);
  const [spec, setSpec] = useState(null);
  const [error, setError] = useState(null);
  const [loadingSpec, setLoadingSpec] = useState(false);
  const [selectedKey, setSelectedKey] = useState("");
  const [baseUrl, setBaseUrl] = useState(BACKEND_URL);
  const [pathParamsJson, setPathParamsJson] = useState("{}");
  const [queryJson, setQueryJson] = useState("{}");
  const [bodyJson, setBodyJson] = useState("{}");
  const [headersJson, setHeadersJson] = useState("{}");
  const [response, setResponse] = useState(null);
  const [busy, setBusy] = useState(false);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const pid = getProjectId();
    setProjectIdState(pid);
    if (!pid) return;
    setLoadingSpec(true);
    api
      .get(`/docs?projectId=${encodeURIComponent(pid)}`)
      .then((res) => {
        setSpec(res.data);
        const ops = listOps(res.data);
        if (ops[0]) setSelectedKey(ops[0].key);
      })
      .catch((err) => setError(err?.response?.data?.message || err.message))
      .finally(() => setLoadingSpec(false));
  }, []);

  const ops = useMemo(() => listOps(spec), [spec]);
  const selected = useMemo(() => ops.find((o) => o.key === selectedKey) || null, [ops, selectedKey]);

  const send = async () => {
    if (!selected) return;
    setBusy(true);
    setResponse(null);
    setError(null);
    const startTime = Date.now();
    try {
      const pathParams = JSON.parse(pathParamsJson || "{}");
      const query = JSON.parse(queryJson || "{}");
      const body = JSON.parse(bodyJson || "{}");
      const extraHeaders = JSON.parse(headersJson || "{}");

      let p = selected.path;
      Object.entries(pathParams || {}).forEach(([k, v]) => {
        p = p.replace(`:${k}`, encodeURIComponent(String(v)));
        p = p.replace(`{${k}}`, encodeURIComponent(String(v)));
      });

      const url = new URL(p, baseUrl);
      Object.entries(query || {}).forEach(([k, v]) => v !== undefined && url.searchParams.set(k, String(v)));

      const res = await fetch(url.toString(), {
        method: selected.method,
        headers: { "Content-Type": "application/json", ...extraHeaders },
        body: ["GET", "HEAD"].includes(selected.method) ? undefined : JSON.stringify(body)
      });

      const duration = Date.now() - startTime;
      const text = await res.text();
      let data = text;
      try { data = JSON.parse(text); } catch {}
      const result = { status: res.status, duration, data };
      setResponse(result);
      setHistory((prev) => [{ key: selected.key, ...result, ts: new Date().toLocaleTimeString() }, ...prev].slice(0, 10));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Layout title="API Explorer">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold dark:text-white">Try endpoints live</h2>
          <div className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
            {projectId
              ? <>Project: <span className="font-mono text-xs bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded">{projectId}</span></>
              : "No project selected."}
          </div>
        </div>
      </div>

      {error && (
        <div className="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/40 dark:bg-red-950/40 dark:text-red-300">
          ⚠ {error}
        </div>
      )}

      {loadingSpec && <div className="mt-4 text-sm text-zinc-400">Loading spec…</div>}

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-[300px_1fr]">
        {/* Endpoint list */}
        <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3">
          <div className="text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">Endpoints</div>
          {ops.length === 0 ? (
            <div className="text-xs text-zinc-400 py-4 text-center">
              {spec ? "No endpoints found." : "Generate docs in Dashboard first."}
            </div>
          ) : (
            <div className="flex flex-col gap-1">
              {ops.map((o) => (
                <button
                  key={o.key}
                  onClick={() => setSelectedKey(o.key)}
                  className={`w-full text-left rounded-lg px-2 py-2 text-sm flex items-center gap-2 transition-colors ${
                    selectedKey === o.key
                      ? "bg-zinc-100 dark:bg-zinc-800"
                      : "hover:bg-zinc-50 dark:hover:bg-zinc-900/50"
                  }`}
                >
                  <span className={`shrink-0 rounded px-1.5 py-0.5 text-xs font-mono font-semibold ${METHOD_COLORS[o.method] || "bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300"}`}>
                    {o.method}
                  </span>
                  <span className="font-mono text-xs truncate dark:text-zinc-200">{o.path}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Request panel */}
        <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-4 space-y-4">
          {selected?.summary && (
            <div className="text-sm text-zinc-600 dark:text-zinc-300 bg-zinc-50 dark:bg-zinc-900 rounded-lg px-3 py-2">
              {selected.summary}
            </div>
          )}

          <div className="flex gap-3 items-end flex-wrap">
            <label className="flex-1 text-sm min-w-0">
              <div className="text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-1">Base URL</div>
              <input
                value={baseUrl}
                onChange={(e) => setBaseUrl(e.target.value)}
                className="w-full rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 py-2 text-sm font-mono"
              />
            </label>
            <button
              onClick={send}
              disabled={!selected || busy}
              className="rounded-lg bg-zinc-900 px-5 py-2 text-sm font-medium text-white disabled:opacity-40 dark:bg-zinc-100 dark:text-zinc-950 hover:opacity-90 transition-opacity"
            >
              {busy ? "Sending…" : "Send →"}
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <JsonTextarea label="Path params (JSON)" value={pathParamsJson} onChange={setPathParamsJson} />
            <JsonTextarea label="Query (JSON)" value={queryJson} onChange={setQueryJson} />
            <JsonTextarea label="Body (JSON)" value={bodyJson} onChange={setBodyJson} />
            <JsonTextarea label="Headers (JSON)" value={headersJson} onChange={setHeadersJson} />
          </div>

          {/* Response */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <div className="text-xs font-semibold uppercase tracking-wider text-zinc-500">Response</div>
              {response && (
                <span className={`text-xs font-mono px-2 py-0.5 rounded ${response.status < 300 ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300" : "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300"}`}>
                  {response.status} · {response.duration}ms
                </span>
              )}
            </div>
            <pre className="overflow-auto rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/40 p-3 text-xs max-h-64">
              {response ? JSON.stringify(response.data, null, 2) : "—"}
            </pre>
          </div>
        </div>
      </div>

      {/* History */}
      {history.length > 0 && (
        <div className="mt-6">
          <div className="text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">Request history</div>
          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 divide-y divide-zinc-100 dark:divide-zinc-800">
            {history.map((h, i) => (
              <div key={i} className="px-4 py-2 flex items-center justify-between text-xs">
                <span className="font-mono text-zinc-600 dark:text-zinc-300">{h.key}</span>
                <div className="flex items-center gap-3 text-zinc-400">
                  <span>{h.ts}</span>
                  <span className={h.status < 300 ? "text-emerald-500" : "text-red-500"}>{h.status}</span>
                  <span>{h.duration}ms</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </Layout>
  );
}
