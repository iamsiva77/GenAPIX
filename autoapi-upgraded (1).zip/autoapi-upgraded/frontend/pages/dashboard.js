import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/router";
import { Layout } from "../components/Layout";
import { api } from "../lib/api";
import { getProjectId, clearProjectId } from "../lib/projectState";

const METHOD_COLORS = {
  GET: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  POST: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
  PUT: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300",
  PATCH: "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300",
  DELETE: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
};

export default function Dashboard() {
  const router = useRouter();
  const [projectId, setProjectIdState] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [docsGenerated, setDocsGenerated] = useState(false);
  const [busy, setBusy] = useState(false);
  const [busyAction, setBusyAction] = useState(null);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const endpoints = useMemo(() => analysis?.endpoints || [], [analysis]);

  useEffect(() => {
    const pid = getProjectId();
    setProjectIdState(pid);
  }, []);

  const showSuccess = (msg) => {
    setSuccess(msg);
    setTimeout(() => setSuccess(null), 3000);
  };

  const runAnalyze = async () => {
    if (!projectId) return;
    setBusy(true);
    setBusyAction("analyze");
    setError(null);
    try {
      const res = await api.post("/analyze", { projectId });
      setAnalysis(res.data.analysis);
      showSuccess(`Found ${res.data.analysis?.stats?.endpoints ?? 0} endpoint(s) across ${res.data.analysis?.frameworks?.join(", ") || "unknown framework"}.`);
    } catch (err) {
      setError(err?.response?.data?.message || err.message);
    } finally {
      setBusy(false);
      setBusyAction(null);
    }
  };

  const runGenerateDocs = async () => {
    if (!projectId) return;
    setBusy(true);
    setBusyAction("docs");
    setError(null);
    try {
      await api.post("/generate-docs", { projectId });
      setDocsGenerated(true);
      showSuccess("OpenAPI spec generated! Head to Documentation or API Explorer.");
    } catch (err) {
      setError(err?.response?.data?.message || err.message);
    } finally {
      setBusy(false);
      setBusyAction(null);
    }
  };

  const handleReset = () => {
    clearProjectId();
    setProjectIdState(null);
    setAnalysis(null);
    setDocsGenerated(false);
    setError(null);
    router.push("/");
  };

  return (
    <Layout title="Dashboard">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold dark:text-white">Project</h2>
          <div className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
            {projectId ? (
              <>ID: <span className="font-mono text-xs bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded">{projectId}</span></>
            ) : (
              <>No project loaded. <a className="underline text-blue-600 dark:text-blue-400" href="/">Upload one</a>.</>
            )}
          </div>
        </div>
        <button
          onClick={handleReset}
          className="rounded-lg border border-zinc-200 px-3 py-2 text-sm hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800 transition-colors"
        >
          Reset / New project
        </button>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <button
          disabled={!projectId || busy}
          onClick={runAnalyze}
          className="rounded-lg bg-zinc-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-40 dark:bg-zinc-100 dark:text-zinc-950 hover:opacity-90 transition-opacity flex items-center gap-2"
        >
          {busyAction === "analyze" ? <span className="animate-spin">⟳</span> : "🔍"}
          Analyze code
        </button>
        <button
          disabled={!projectId || busy || !analysis}
          onClick={runGenerateDocs}
          title={!analysis ? "Run Analyze first" : ""}
          className="rounded-lg border border-zinc-200 px-4 py-2 text-sm hover:bg-zinc-100 disabled:opacity-40 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800 transition-colors flex items-center gap-2"
        >
          {busyAction === "docs" ? <span className="animate-spin">⟳</span> : "📄"}
          Generate OpenAPI
        </button>
        {docsGenerated && (
          <>
            <a href="/docs" className="rounded-lg border border-zinc-200 px-4 py-2 text-sm hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800 transition-colors">
              📖 View docs
            </a>
            <a href="/explorer" className="rounded-lg border border-zinc-200 px-4 py-2 text-sm hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800 transition-colors">
              🧪 Explorer
            </a>
            <a href="/sdk" className="rounded-lg border border-zinc-200 px-4 py-2 text-sm hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800 transition-colors">
              ⬇️ SDKs
            </a>
          </>
        )}
      </div>

      {success && (
        <div className="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-900/40 dark:bg-emerald-950/30 dark:text-emerald-300">
          ✓ {success}
        </div>
      )}
      {error && (
        <div className="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/40 dark:bg-red-950/40 dark:text-red-300">
          ⚠ {error}
        </div>
      )}

      {analysis && (
        <div className="mt-4 grid grid-cols-3 gap-3">
          <div className="rounded-lg border border-zinc-100 dark:border-zinc-800 p-3 text-center">
            <div className="text-2xl font-bold dark:text-white">{analysis.stats?.endpoints ?? 0}</div>
            <div className="text-xs text-zinc-500 mt-0.5">Endpoints</div>
          </div>
          <div className="rounded-lg border border-zinc-100 dark:border-zinc-800 p-3 text-center">
            <div className="text-2xl font-bold dark:text-white">{analysis.stats?.jsFiles ?? 0}</div>
            <div className="text-xs text-zinc-500 mt-0.5">JS files</div>
          </div>
          <div className="rounded-lg border border-zinc-100 dark:border-zinc-800 p-3 text-center">
            <div className="text-2xl font-bold dark:text-white">{analysis.stats?.pyFiles ?? 0}</div>
            <div className="text-xs text-zinc-500 mt-0.5">Python files</div>
          </div>
        </div>
      )}

      <div className="mt-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500">Endpoints</h3>
          {endpoints.length > 0 && (
            <span className="text-xs text-zinc-400">{endpoints.length} found</span>
          )}
        </div>
        <div className="overflow-hidden rounded-xl border border-zinc-200 dark:border-zinc-800">
          {endpoints.length ? (
            <div className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {endpoints.map((e, idx) => (
                <div key={`${e.method}-${e.path}-${idx}`} className="flex items-center justify-between px-4 py-3 hover:bg-zinc-50 dark:hover:bg-zinc-900/50 transition-colors">
                  <div className="flex items-center gap-3 min-w-0">
                    <span className={`shrink-0 rounded-md px-2 py-0.5 text-xs font-semibold font-mono ${METHOD_COLORS[e.method] || "bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300"}`}>
                      {e.method}
                    </span>
                    <span className="font-mono text-sm truncate dark:text-zinc-200">{e.path}</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0 ml-2">
                    {e.file && <span className="text-xs text-zinc-400 hidden sm:block truncate max-w-[140px]" title={e.file}>{e.file}</span>}
                    <span className="text-xs text-zinc-400 bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded">{e.source}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="px-4 py-10 text-sm text-zinc-400 text-center">
              {analysis ? "No endpoints detected." : "Click 'Analyze code' to detect endpoints."}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
