import { useState, useCallback } from "react";
import { useRouter } from "next/router";
import { api } from "../lib/api";
import { setProjectId } from "../lib/projectState";

export default function Home() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [dragOver, setDragOver] = useState(false);

  const uploadFile = useCallback(async (file) => {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".zip")) {
      setError("Please upload a .zip file.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await api.post("/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      setProjectId(res.data.projectId);
      router.push("/dashboard");
    } catch (err) {
      setError(err?.response?.data?.message || err.message || "Upload failed");
    } finally {
      setBusy(false);
    }
  }, [router]);

  const onFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) uploadFile(file);
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) uploadFile(file);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-zinc-50 dark:bg-zinc-950">
      <div className="w-full max-w-xl">
        <div className="rounded-2xl border border-zinc-200 bg-white p-8 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
          <div className="flex items-start justify-between gap-6">
            <div>
              <h1 className="text-3xl font-semibold tracking-tight dark:text-white">AutoAPI Gen</h1>
              <p className="mt-2 text-zinc-500 dark:text-zinc-400 text-sm leading-relaxed">
                Upload an Express or FastAPI backend ZIP to generate OpenAPI docs,
                an interactive explorer, and downloadable client SDKs.
              </p>
            </div>
            <a
              href="/dashboard"
              className="shrink-0 rounded-lg border border-zinc-200 px-4 py-2 text-sm hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800 transition-colors"
            >
              Dashboard
            </a>
          </div>

          <div className="mt-8">
            <label
              className={[
                "flex flex-col items-center justify-center cursor-pointer rounded-xl border-2 border-dashed px-6 py-10 transition-colors",
                dragOver ? "border-blue-400 bg-blue-50 dark:border-blue-500 dark:bg-blue-950/20" : "border-zinc-300 hover:border-zinc-400 dark:border-zinc-700 dark:hover:border-zinc-500",
                busy ? "opacity-50 pointer-events-none" : ""
              ].join(" ")}
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={onDrop}
            >
              <div className="text-4xl mb-3">{busy ? "⏳" : "📦"}</div>
              <div className="text-sm font-medium dark:text-white">
                {busy ? "Uploading and extracting…" : "Drop your ZIP here or click to browse"}
              </div>
              <div className="mt-1 text-xs text-zinc-400">Express or FastAPI project · Max 50 MB</div>
              <input type="file" accept=".zip" onChange={onFileChange} disabled={busy} className="hidden" />
            </label>
          </div>

          {error && (
            <div className="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/40 dark:bg-red-950/40 dark:text-red-300">
              ⚠ {error}
            </div>
          )}

          <div className="mt-6 grid grid-cols-3 gap-3 text-center text-xs text-zinc-500 dark:text-zinc-400">
            {[["🔍", "Analyze routes"], ["📄", "Generate OpenAPI"], ["⬇️", "Download SDKs"]].map(([icon, label]) => (
              <div key={label} className="rounded-lg border border-zinc-100 dark:border-zinc-800 p-3">
                <div className="text-lg mb-1">{icon}</div>
                <div>{label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
