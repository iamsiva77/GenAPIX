import { useEffect, useState } from "react";
import { Layout } from "../components/Layout";
import { api } from "../lib/api";
import { getProjectId } from "../lib/projectState";

const LANGUAGES = [
  { id: "javascript", label: "JavaScript", icon: "🟨", desc: "ES module with axios, tree-shakeable" },
  { id: "python", label: "Python", icon: "🐍", desc: "Requests-based, pip-installable" },
  { id: "java", label: "Java", icon: "☕", desc: "OkHttp-based, Maven/Gradle ready" },
];

export default function SDK() {
  const [projectId, setProjectIdState] = useState(null);
  const [busyLang, setBusyLang] = useState(null);
  const [error, setError] = useState(null);
  const [downloaded, setDownloaded] = useState([]);

  useEffect(() => {
    setProjectIdState(getProjectId());
  }, []);

  const download = async (language) => {
    setBusyLang(language);
    setError(null);
    try {
      const res = await api.post(
        "/sdk",
        { projectId, language },
        { responseType: "blob", validateStatus: () => true }
      );
      if (res.status >= 400) {
        const txt = await res.data.text();
        let msg = txt;
        try { msg = JSON.parse(txt)?.message || txt; } catch {}
        throw new Error(msg || `HTTP ${res.status}`);
      }
      const blob = new Blob([res.data], { type: "application/zip" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `autoapi-sdk-${language}.zip`;
      a.click();
      URL.revokeObjectURL(url);
      setDownloaded((prev) => [...new Set([...prev, language])]);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusyLang(null);
    }
  };

  return (
    <Layout title="SDK Downloads">
      <h2 className="text-xl font-semibold dark:text-white">Client SDKs</h2>
      <p className="mt-2 text-sm text-zinc-500 dark:text-zinc-400">
        Download a ready-to-use client SDK generated from your OpenAPI spec.
        Each SDK includes a typed client class and per-endpoint helper functions.
      </p>

      <div className="mt-3 text-sm text-zinc-500 dark:text-zinc-400">
        {projectId ? (
          <>Project: <span className="font-mono text-xs bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded">{projectId}</span></>
        ) : (
          <>No project selected. <a href="/" className="underline text-blue-500">Upload one first</a>.</>
        )}
      </div>

      {error && (
        <div className="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/40 dark:bg-red-950/40 dark:text-red-300">
          ⚠ {error}
        </div>
      )}

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        {LANGUAGES.map(({ id, label, icon, desc }) => (
          <button
            key={id}
            disabled={!projectId || !!busyLang}
            onClick={() => download(id)}
            className="group rounded-xl border border-zinc-200 px-5 py-5 text-left hover:border-zinc-400 hover:bg-zinc-50 disabled:opacity-40 dark:border-zinc-700 dark:hover:border-zinc-500 dark:hover:bg-zinc-900/50 transition-colors relative"
          >
            {downloaded.includes(id) && (
              <span className="absolute top-3 right-3 text-xs text-emerald-600 dark:text-emerald-400">✓ Downloaded</span>
            )}
            <div className="text-3xl mb-3">{busyLang === id ? "⏳" : icon}</div>
            <div className="text-sm font-semibold dark:text-white">{label}</div>
            <div className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">{desc}</div>
            <div className="mt-3 text-xs font-medium text-blue-600 dark:text-blue-400">
              {busyLang === id ? "Generating…" : "Download ZIP →"}
            </div>
          </button>
        ))}
      </div>

      <div className="mt-6 rounded-lg border border-zinc-100 dark:border-zinc-800 p-4 text-xs text-zinc-500 dark:text-zinc-400">
        <strong className="dark:text-zinc-300">Usage:</strong> Each SDK ZIP contains a client class and individual function per endpoint.
        JS SDK uses <code className="bg-zinc-100 dark:bg-zinc-800 px-1 rounded">axios</code>,
        Python uses <code className="bg-zinc-100 dark:bg-zinc-800 px-1 rounded">requests</code>,
        Java uses <code className="bg-zinc-100 dark:bg-zinc-800 px-1 rounded">OkHttp</code>.
      </div>
    </Layout>
  );
}
