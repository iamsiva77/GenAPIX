import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { Layout } from "../components/Layout";
import { api } from "../lib/api";
import { getProjectId } from "../lib/projectState";

const SwaggerUI = dynamic(() => import("swagger-ui-react"), { ssr: false });

export default function Docs() {
  const [projectId, setProjectIdState] = useState(null);
  const [spec, setSpec] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const pid = getProjectId();
    setProjectIdState(pid);
    if (!pid) return;
    setLoading(true);
    api
      .get(`/docs?projectId=${encodeURIComponent(pid)}`)
      .then((res) => setSpec(res.data))
      .catch((err) => setError(err?.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <Layout title="Documentation">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold dark:text-white">OpenAPI Documentation</h2>
          <div className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
            {projectId ? (
              <>Project: <span className="font-mono text-xs bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded">{projectId}</span></>
            ) : (
              <>No project selected.</>
            )}
          </div>
        </div>
        <div className="flex gap-2">
          {spec && (
            <button
              onClick={() => {
                const blob = new Blob([JSON.stringify(spec, null, 2)], { type: "application/json" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = "openapi.json";
                a.click();
                URL.revokeObjectURL(url);
              }}
              className="rounded-lg border border-zinc-200 px-3 py-2 text-sm hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800 transition-colors"
            >
              ⬇ openapi.json
            </button>
          )}
          <a href="/dashboard" className="rounded-lg border border-zinc-200 px-3 py-2 text-sm hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800 transition-colors">
            ← Back
          </a>
        </div>
      </div>

      {error && (
        <div className="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/40 dark:bg-red-950/40 dark:text-red-300">
          ⚠ {error}
        </div>
      )}

      <div className="mt-6 overflow-hidden rounded-xl border border-zinc-200 dark:border-zinc-800">
        {loading ? (
          <div className="px-4 py-10 text-sm text-zinc-400 text-center">Loading spec…</div>
        ) : spec ? (
          <div className="swagger-wrapper bg-white dark:bg-zinc-950">
            <SwaggerUI spec={spec} />
          </div>
        ) : (
          <div className="px-4 py-10 text-sm text-zinc-400 text-center">
            {projectId
              ? "No docs generated yet. Go to Dashboard → Generate OpenAPI."
              : <>No project selected. <a href="/" className="underline text-blue-500">Upload one</a>.</>}
          </div>
        )}
      </div>
    </Layout>
  );
}
